package edu.neu.madcourse.sticky.Login;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import edu.neu.madcourse.sticky.R;
import edu.neu.madcourse.sticky.utils.Utils;

public class LoginPage extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
    }

    public void loginUser(View view) {
        EditText userNameField = (EditText)findViewById(R.id.userNameInput);
        String userName = userNameField.getText().toString();
        if(userName.equals("")) {
            Utils.postToastMessage("Username cannot be empty", getApplicationContext());
        } else {
            Utils.setProperties(getApplicationContext(), "STICKY_USER_NAME", userName);
            finish();
        }
    }

    // prevent user skip the login page
    @Override
    public void onBackPressed() {}
}