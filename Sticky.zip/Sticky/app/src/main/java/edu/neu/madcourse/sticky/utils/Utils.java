package edu.neu.madcourse.sticky.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class Utils {

    public static void setProperties(Context context, String key, String value)  {
        SharedPreferences preferences = context.getSharedPreferences(key, context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String getProperties(Context context, String key)  {
        SharedPreferences preferences = context.getSharedPreferences(key, context.MODE_PRIVATE);
        return preferences.getString(key, "");
    }

    public static void postToastMessage(final String message, final Context context){
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

}
